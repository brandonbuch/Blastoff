function countDown() {
    // Purpose of this function is to start the countdown
    // Declare variables
    var countdown = 10;
    // 1000 = 1 sec because using milliseconds
    var timeout = 10000;
    // used to set timeout
    setTimeout(() => {
     document.getElementById("CountdownDisplay").innerHTML = "Blastoff!";
     countdown = countdown - 1; 
    }, timeout)
    timeout = timeout - 1000;
    // First is zero this is ONE
    setTimeout(() => 
    {document.getElementById("CountdownDisplay").innerHTML = countdown;
     countdown = countdown - 1; 
    }, timeout)
    timeout = timeout - 1000;
    // Two
    setTimeout(() => 
    {document.getElementById("CountdownDisplay").innerHTML = countdown;
     countdown = countdown - 1; 
    }, timeout)
    timeout = timeout - 1000;
    // Three
    setTimeout(() => 
    {document.getElementById("CountdownDisplay").innerHTML = countdown;
     countdown = countdown - 1; 
    }, timeout)
    timeout = timeout - 1000;
    // Four
    setTimeout(() => 
    {document.getElementById("CountdownDisplay").innerHTML = countdown;
     countdown = countdown - 1; 
    }, timeout)
    timeout = timeout - 1000;
    // Five
    setTimeout(() => 
    {document.getElementById("CountdownDisplay").innerHTML = countdown;
     countdown = countdown - 1; 
    }, timeout)
    timeout = timeout - 1000;
    // Six
    setTimeout(() => 
    {document.getElementById("CountdownDisplay").innerHTML = countdown;
     countdown = countdown - 1; 
    }, timeout)
    timeout = timeout - 1000;
    // Seven
    setTimeout(() => 
    {document.getElementById("CountdownDisplay").innerHTML = countdown;
     countdown = countdown - 1; 
    }, timeout)
    timeout = timeout - 1000;
    // Eight 
    setTimeout(() => 
    {document.getElementById("CountdownDisplay").innerHTML = countdown;
     countdown = countdown - 1; 
    }, timeout)
    timeout = timeout - 1000;
    // Nine 
     setTimeout(() => 
    {document.getElementById("CountdownDisplay").innerHTML = countdown;
     countdown = countdown - 1; 
    }, timeout)
    timeout = timeout - 1000;
    // Ten
    setTimeout(() => 
    {document.getElementById("CountdownDisplay").innerHTML = countdown;
     countdown = countdown - 1; 
    }, timeout)
    timeout = timeout - 1000;
    // Eleven
    setTimeout(() => 
    {document.getElementById("CountdownDisplay").innerHTML = countdown;
     countdown = countdown - 1; 
    }, timeout)
    timeout = timeout - 1000;
}